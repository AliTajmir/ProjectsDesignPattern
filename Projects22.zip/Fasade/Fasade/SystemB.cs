﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Fasade
{
  public  class SystemB
    {
      public void operation1() 
      {
          MessageBox.Show("SystemB Added!");
      }
        public void operation2()
        {
            MessageBox.Show("SystemB is runing");
        }
    }
}
