﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Fasade
{
  public  class SystemA
    {
      public void operation1() 
      {
          MessageBox.Show("SystemA Added");
      
      }
        public void operation2()
        {
            MessageBox.Show("SystemA is runing");

        }
    }
}
